package com.atguigu.paymentdemo.mapper;

import com.atguigu.paymentdemo.entity.RefundInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface RefundInfoMapper extends BaseMapper<RefundInfo> {

}
