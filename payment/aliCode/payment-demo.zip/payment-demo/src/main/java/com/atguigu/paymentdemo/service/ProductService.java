package com.atguigu.paymentdemo.service;

import com.atguigu.paymentdemo.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;

public interface ProductService extends IService<Product> {

}
