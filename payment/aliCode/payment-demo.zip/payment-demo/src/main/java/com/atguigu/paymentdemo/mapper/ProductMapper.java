package com.atguigu.paymentdemo.mapper;

import com.atguigu.paymentdemo.entity.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ProductMapper extends BaseMapper<Product> {

}
