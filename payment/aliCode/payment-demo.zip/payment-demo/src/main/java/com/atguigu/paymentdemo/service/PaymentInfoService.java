package com.atguigu.paymentdemo.service;

public interface PaymentInfoService {

    void createPaymentInfo(String plainText);
}
